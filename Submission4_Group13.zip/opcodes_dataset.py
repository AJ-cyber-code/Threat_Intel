import os
import csv

# Directory containing .opcode files
opcode_dir = "C:\\Users\\as998\\OneDrive\\Documents\\Opcodes_Group13"
# Output CSV file path
output_csv = "C:\\Users\\as998\\OneDrive\\Documents\\opcodes_dataset.csv"

# Mapping of group names to labels
group_labels = {
    "admin@338": "1", "ajax": "2", "apt1": "3", "apt12": "4", "apt19": "5",
    "apt28": "6", "apt29": "7", "apt3": "8", "apt30": "9", "apt33": "10",
    "apt39": "11", "axiom": "12", "bluemockingbird": "13", "bronzebutler": "14",
    "chimera": "15", "cobaltgroup": "16", "darkvishnya": "17", "deeppanda": "18",
    "dragonfly": "19", "dragonfly2": "20", "elderwood": "21", "evilnumgroup": "22",
    "fin5": "23", "fin7": "24", "gallium": "25", "gamaredon": "26", "hafnium": "27",
    "ke3chang": "28", "menupass": "29", "moafee": "30", "patchwork": "31",
    "sandwormteam": "32", "sidewinder": "33","tempveles": "34", "turla": "35"
}

def parse_filename(filename):
    
    # Remove spaces, convert to lowercase, get the part before underscore
    group_name = filename.split('_')[0].replace(" ", "").lower()
    label = group_labels.get(group_name)  # Get the label from the dictionary
    return label, group_name

# Prepare list to store CSV rows and skipped files for reporting
rows = []
skipped_files = []

# Process each file in the directory
for filename in os.listdir(opcode_dir):
    if filename.endswith(".opcode"):
        filepath = os.path.join(opcode_dir, filename)
        
        # Extract label from filename
        label, group_name = parse_filename(filename)
        if label is None:
            skipped_files.append((filename, group_name))
            continue
        
        with open(filepath, 'r') as file:
            opcodes = [line.strip() for line in file] 
        
        opcodes_str = ",".join(opcodes)
        
        rows.append({"apt": label, "opcodes": opcodes_str})

# Write all collected data to CSV
with open(output_csv, 'w', newline='') as csvfile:
    fieldnames = ["apt", "opcodes"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()  
    writer.writerows(rows)  

# Print summary
print(f"CSV file created at: {output_csv}")
if skipped_files:
    print("\nSkipped files due to missing labels:")
    for file, group in skipped_files:
        print(f"{file} (Group: {group})")
