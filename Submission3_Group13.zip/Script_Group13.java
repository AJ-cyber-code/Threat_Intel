import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.listing.Instruction;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ExportOpcodes extends GhidraScript {
    @Override
    protected void run() throws Exception {
        String outputDir = System.getProperty("user.home") + "/Opcodes_Group13"; // Set output directory

        // Ensure the output directory exists
        File directory = new File(outputDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Get the program name without the extension
        String programName = currentProgram.getName();
        int extensionIndex = programName.lastIndexOf('.');
        if (extensionIndex > 0) {
            programName = programName.substring(0, extensionIndex); // Remove the extension
        }

        // Create the output file with .opcode extension
        File outputFile = new File(outputDir, programName + ".opcode");
        try (FileWriter writer = new FileWriter(outputFile)) {
            Listing listing = currentProgram.getListing();
            var instructions = listing.getInstructions(true); // Get all instructions in the program

            // Loop through each instruction and write only the mnemonic (instruction name)
            while (instructions.hasNext()) {
                Instruction instruction = instructions.next();
                String mnemonic = instruction.getMnemonicString(); // Get the mnemonic (e.g., MOV, PUSH)
                writer.write(mnemonic + "\n"); // Write the mnemonic to the file with a newline
            }

            writer.flush();
            println("Instruction mnemonics exported to: " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            println("Error writing mnemonics: " + e.getMessage());
        }
    }
}
